<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="test.css">
<title>test PHP</title>
</head>



<body>
 <?php /*include kommandoen, inkludere den valgt fil på side, så man "kun" skal rette i den ene fil, og ikke alle 3*/
		
	include 'menu.php';?>
<div class="text"> Dette er side 1, det er en dejlig side, hvor man kun skal gøre tingene 1 gang, før man når i mål med ens opgave, og det er rigtig dejligt</div>

 	
	

    
    <?php 
		
	include 'footer.php';?>
        
        
        


        

</body>
</html>



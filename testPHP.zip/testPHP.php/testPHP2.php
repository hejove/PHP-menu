<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="test.css">
<title>testPHP2</title>
</head>

<body>
  <?php /*include kommandoen, inkludere den valgt fil på side, så man "kun" skal rette i den ene fil, og ikke alle 3*/
		
	include 'menu.php';?>
<<div class="text"> Side 3 er bare "side 3", her kan man hygge og prøve sig lidt frem, det behøves ikke og gå stærkt, der skal bare ske noget kreativt</div>




  <?php 
		
	include 'footer.php';?>
</body>
</html>
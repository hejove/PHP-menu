<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="test.css">
<title>footer</title>
</head>

<body>

<?php /*seperate footer fil, med den samme inklude kommando på hver af de enkle sider, så man kun skal ændre herinde*/
echo "<h3>Cecilie Kogi Carlsen <br>Kontakt mig på 11223344 eller på mail 123@123.dk</h3>";
?>

</body>
</html>
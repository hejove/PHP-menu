<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="test.css">
<title>testPHP1</title>
</head>

<body>
<?php /*include kommandoen, inkludere den valgt fil på side, så man "kun" skal rette i den ene fil, og ikke alle 3*/
		
	include 'menu.php';?>
<div class="text"> Så nåede vi til side 2, denne side er lidt speciel, her får man lov til og lave 1 fejl, men derefter skal tingene gøres korrekt</div>



  
    
    

  <?php 
		
	include 'footer.php';?>
</body>
</html>